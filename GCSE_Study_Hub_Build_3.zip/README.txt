GCSE Study Hub — Build 3
=========================
Open index.html in a modern browser.

Included:
- 9 subject areas and module structure
- starter lesson library for Biology, Chemistry, Physics and Maths
- visualisation prompts, key vocabulary and Grade 8/9 challenges
- adaptive quiz with topic mastery
- end-of-module written test prototype
- progress centre
- Dentist Path
- exam board selector (can remain Not set yet)
- local browser saving via localStorage

Important:
This is a working browser prototype, not a hosted online service. Exact exam-board specifications and full mark schemes should be attached after the student's exam boards are known. The structure is designed so that layer can be added later.

The curriculum architecture follows the England GCSE subject-content framework and Ofqual assessment-objective approach. See the official sources in the project notes below.
